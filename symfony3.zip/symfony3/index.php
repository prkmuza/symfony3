
<!Doctype html 5>

<html>
<head> 
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=0">
	<meta name="keywords" content="SocialPlacesApp, online store,online shopping,free delivery,food,mazowe,beverage,community,Zimbabwe,Africa,Cape Town, South Africa">
	<meta name="description" content="SocialPlacesApp online store">
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="SocialPlacesApp online store"/>
    <meta property="og:type" content="website"/>
    <meta property="og:url" content="https://www.SocialPlacesApp.co.za"/>
    <meta property="og:image" content="https://www.SocialPlacesApp.co.za/SiteImages/ZELogo.png"/>
    <meta property="og:site_name" content="SocialPlacesApp"/>
    <meta property="og:description" content="SocialPlacesApp online store."/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <link rel="shortcut icon" href="SiteImages/ZELogo.png"/>
    <link rel="stylesheet" type="text/css" href="../MainstyleMobile.css"/>
	<script src='https://www.google.com/recaptcha/api.js'></script>
    <title>SocialPlacesApp</title>
		<script src="../js/responsive-nav.js"></script>
</head>

<body id="TheBody" bgcolor="#e2e1e0" >

     <header>
	 
      <a  class="logo" data-scroll>
 <div id="MainLogo"></div>
 <div><h2 id="KickMainLabel" style="color:#000000;">
SocialPlacesApp
 </h2></div>
 </a>
 
      <nav class="nav-collapse">
        <ul>

			
		 
        </ul>
      </nav>
    </header>
	<br><br><br>

<br>	
	<div style="max-width:380px;min-height:380px;margin:0 auto;border-radius:5px;background-color:#ffffff;">
	
	
	<div style="width:260px;margin:0 auto;text-align:center;">
	
	<h3>Contact Page</h3>
	
	<div id="showdetail">
		 <p id="mainperson" class="KGSZBorder" > 
		 
		   <input id="Name" name="Name" type="text" class="textox" style="margin-bottom:20px;"  Placeholder="Enter your name..."><br>
		   <input id="CellNum" name="CellNum" type="text" class="textox" style="margin-bottom:20px;"  Placeholder="Enter your Cell phone number..."><br>
		    <input id="Email" name="Email" type="text" class="textox" style="margin-bottom:20px;"  Placeholder="Enter your email..."><br>
			
			
			<div id="opt_widget_id" class="g-recaptcha" data-sitekey="6Lc93HkUAAAAACjx_0eVZH9PjaSmDWdivoJZJfeh"></div>
	 
		<br>
			  <button id="mainbtnconfirm" class="btn" style="cursor:pointer;" onclick="SendContact();">Send</button>
		
		</p>
	
	</div>
	
	<div id="contactResponse">
	
	</div>
	
	
	<div style="clear:both;"></div>
	
	</div>
	
	</div>

<script src="../js/jquery.min.js"></script>
<script src="../js/jquery-1.4.2.min.js"></script>
	<script src="../js/1.4.4 jquery.js"></script>
	<script src="../js/1.12.2  jquery.js"></script>
<script src="../js/fastclick.js"></script>
    <script src="../js/scroll.js"></script>
    <script src="../js/fixed-responsive-nav.js"></script>	

	
   </body>
</html>

	<script>
	
	function SendContact(){
		
	var name = $('#Name').val(); //Validierung der Form-Daten
    var cellnum = $('#CellNum').val();
    var email = $('#Email').val();
	
	if(name == "" || cellnum == "" || email == "" || grecaptcha.getResponse() == "")
	{
		alert('please fill in all the details above and confirm you are not a robot');
	}else{
		
		var xhttp2 = new XMLHttpRequest();
     xhttp2.onreadystatechange = function() {
     if (xhttp2.readyState == 4 && xhttp2.status == 200) {
     document.getElementById("contactResponse").innerHTML = xhttp2.responseText;
	 
	 var str = xhttp2.responseText;
     if(str.includes("Thanks"))
	 {
		 document.getElementById("showdetail").style.display = "none";
	 }
	 
     }
     };
     xhttp2.open("GET", "contact.php?name="+name+"&cellnum="+cellnum+"&email="+email, true);
    xhttp2.send(); 
	}


	
	
	//
	}
	
	</script>
