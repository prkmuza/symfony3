<?php

namespace PanasheBundle\PanasheBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PanasheBundlePanasheBundle extends Bundle
{
}
