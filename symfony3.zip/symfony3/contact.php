<?php
$email = $_GET['email'];
$name = $_GET['name'];
$cellnum = $_GET['cellnum'];
$date = date("Y-m-d");

if((!filter_var($email, FILTER_VALIDATE_EMAIL)) ){
	echo'

	
	<text style="color:red;">Hmm something seems to be wrong with your email, make sure you fill in all the details above correctly...</text>';
}else{
	
	$mailheader  = 'MIME-Version: 1.0' . "\r\n";
$mailheader .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$mailheader .= "From: socialplaces<info@socialplaces.co.za>" . "\r\n" .  'X-Mailer: PHP/' . phpversion();

$message = '<html><body style="text-align:left;">';
$message .= '<div id="MailBody" style="background-color:#FAFBFF;">';
$message.='<img src="https://socialplaces.co.za/wp-content/uploads/2017/05/Social-Places-Logo-SMALL.png" height="55">';
$message .= "<h2>Message from $name,</h2><h3>...</h3>";

//mail msg to sender
	mail("$email", "Message From SocialPlaces","$message \n 
	
	<div style='max-width:500px;background-color:#ffffff;border-radius:5px;margin:5px;padding:5px;border:solid grey;border-width:1px;'>
	     Message:<br><h2'>Thanks for getting in touch with us we will call you on $cellnum</h2><br>
	</div>
	
</div>	
</body></html>",$mailheader,'-f info@socialplaces.co.za');

//mail msg to app manager
	mail("panamuza@yahoo.com", "Message From SocialPlaces","$message \n 
	
	<div style='max-width:500px;background-color:#ffffff;border-radius:5px;margin:5px;padding:5px;border:solid grey;border-width:1px;'>
	     Message:<br><h2'>Hi Application manager,
<br>
		 $name wants you to call on $cellnum or email them on $email.</h2><br>
	</div>
	
	Thanks,
	
</div>	
</body></html>",$mailheader,'-f info@socialplaces.co.za');


echo"<h2>Thanks, your message has successfully been received... :). We will get back to you as soon as possible</h2>

";

//save contact details in DB

$servername = "197.242.144.48";
$username = "xxxxxxxxxx";//let me know if you need this
$password = "xxxxxxxxxxxxx";//let me know if you need this
$dbname = "stakepdn_main";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

				//Now lets add the details to db
			  $sql2 = "INSERT INTO SocialPlaces (Name,CellNum,Email,Date) VALUES ('$name','$cellnum','$email','$date') ";
              $result2 = $conn->query($sql2);

                    if ($result2->num_rows > 0) {
                       while($row2 = $result2->fetch_assoc()) {
			           }
			        }

}

?>
