<?php
//save contact details in DB

$servername = "197.242.144.48";
$username = "xxxxxxxxx";//let me know if you need this
$password = "xxxxxxxxxxxxxx";//let me know if you need this
$dbname = "stakepdn_main";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

             $sql1 = "SELECT * FROM SocialPlaces ";
              $result1 = $conn->query($sql1);

              if ($result1->num_rows > 0) {
				  
				  					echo"
					<div style='width:600px;'>
					   <div style='width:50px;float:left'> ID</div> 
					   <div style='width:100px;float:left'> Name</div> 
					   <div style='width:100px;float:left'> Cell Number</div> 
					   <div style='width:200px;float:left'> Email</div>
					   <div style='width:100px;float:left;padding-left:10px;'> Date</div>
					<div style='clear:both;'></div>
					</div><br>
					
					";
             
              while($row1 = $result1->fetch_assoc()) {
				  
				$ID = $row1['ID'];
				$Name = $row1['Name'];
				$CellNum = $row1['CellNum'];
				$Email = $row1['Email'];
				$date= $row1['Date'];

					echo"
					<div style='width:600px;border-bottom:solid 1px black;font-size:15px;'>
					   <div style='width:50px;float:left;overflow:hidden;'> $ID</div>
					   <div style='width:100px;float:left;overflow:hidden;'> $Name</div> 
					   <div style='width:100px;float:left;overflow:hidden;'>$CellNum</div> 
					   <div style='width:200px;float:left;overflow:hidden;'> $Email</div> 
					   <div style='width:100px;float:left;overflow:hidden;padding-left:10px;'>$date</div>
					   <div style='clear:both;'></div>
					
					</div><br>
					
					";
				}
			  }

?>
